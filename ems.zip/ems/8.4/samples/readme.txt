 =================================================================
 TIBCO Enterprise Message Service
 Copyright (c) 2001-2017 TIBCO Software Inc.
 ALL RIGHTS RESERVED
 =================================================================

 This directory contains samples for TIBCO Enterprise Message Service.

 Directory 'config' contains examples of the server configuration
 files (unavailable on 32-bit Windows).

 Directory 'config/jaas' contains examples of the server JAAS 
 configuration files (unavailable on 32-bit Windows).

 Directory 'certs' contains sample certificates.

 Directory 'admin' contains examples of EMS administration API.

 Directory 'c' contains examples of C client usage.

 Directory 'cs' contains examples of C# client usage (Windows only).
 
 Java samples are available from Sun Microsystems, Inc.
